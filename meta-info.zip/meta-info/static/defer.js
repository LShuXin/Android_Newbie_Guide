console.log('defer.js loaded!') // eslint-disable-line no-console
