console.log('head.js loaded!') // eslint-disable-line no-console
